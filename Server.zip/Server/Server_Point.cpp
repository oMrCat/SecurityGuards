#include"NetWorkClient.h"

int main(int argc, char* argv[])
{
	NetWorkClient obj;
	obj.m_argc = argc;
	for (int i = 0; i < sizeof(argv); i++)
	{
		obj.m_argv[i] = argv[i];
	}
	obj.NetMain();
	return 0;
}