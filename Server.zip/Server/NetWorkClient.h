#pragma once
#include <vector>
#include<WS2tcpip.h>
#include<WinSock2.h>
#include<atlstr.h>
#include<stdio.h>
#include<string>
#include<algorithm>
#include "include\mysql.h" 
#pragma comment(lib,".\\libmysql.lib")
#pragma comment(lib,"ws2_32.lib")

using namespace std;
class NetWorkClient
{
public:
	void NetMain();
	void MysqlInit(int argc, char* argv[]);
	void sql_insert(MYSQL* mysql,const char*sql);
	void sql_check_result(MYSQL* mysql);
	void sql_select(MYSQL* mysql, const char* sql);
	void MysqlSelect();
	void MysqlSelect_black();
	SOCKET client;
	MYSQL mysql;
public:
	int m_argc;
	char* m_argv[];
};

